<?php

$dbhost = "localhost"
$dbname = "db_login"
$dbuser = "root"
$dbpassword = "";

$koneksi = mysql_connect($dbhost,$dbuser,$dbpassword) or die ("Koneksi ke server error!");
mysql_select_db($dbname,$koneksi) or die ("Koneksi ke database error!");
?>