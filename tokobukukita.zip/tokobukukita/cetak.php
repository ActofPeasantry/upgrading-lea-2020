<!DOCTYPE html>
<html>
<head>
	<title>CETAK PRINT LAPORAN</title>
</head>
<body>
	<center>
		<h4>TOKO BUKU</h4>
		<h2>DATA LAPORAN BUKU YANG TERJUAL BULAN INI</h2>
	</center>

	<?php
	include 'dbconnect.php';
	?>

	<table border="1" style="width": 100%>
		<tr>
			<th width="1%">No</th>
			<th>Judul Buku</th>
			<th>Penerbit Buku</th>
			<th>Genre Buku</th>
			<th width="20%">Harga Buku</th>
			<th width="5%">Jumlah Buku</th>
		</tr>

		<?php
		$no = 1;
		$query = "SELECT * FROM buku";
		// $conn = mysqli_connect($host, $user, $password, $dbname);
		// $result = mysqli_query($conn , $query);
		// while($row = mysqli_fetch_array($query))
		{
			echo "<tr>";

			
			echo "<td>".$no++;"</td>";
			echo "<td>".$query['judul_buku']."</td>";
			echo "<td>".$query['penerbit_buku']."</td>";
			echo "<td>".$query['genre_buku']."</td>";
			echo "<td>".$query['harga_buku']."</td>";
			echo "<td>".$query['jumlah_buku']."</td>";

			echo "<tr>";
		}
		?>
	</table>

	<script type="text/javascript">
		window.print();
	</script>

</body>
</html>